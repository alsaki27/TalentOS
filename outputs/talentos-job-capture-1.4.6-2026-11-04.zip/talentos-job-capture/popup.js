const DEFAULT_URL = 'https://talent.skarion.com';
const DEFAULT_API_KEY = ''; // filled in below once issued
let settings = { baseUrl: DEFAULT_URL, apiKey: DEFAULT_API_KEY };
let tab = null, kind = 'single', hasOpenJob = false;
let currentJob = null, currentJobId = null, currentEligibility = null;
let pickerCandidates = [], assignmentOwners = [], assignedByLabel = '', defaultOwnerUserId = '';
let draftCandidate = null, selectedCandidates = [];
let activeCandidateSelectionId = '';
let assignmentStatus = 'assigned', assignmentDueAt = '', assignmentNote = '';
let candidateListGeneration = 0;
const $ = (i) => document.getElementById(i);
const setStatus = (m, k = '', p = null) => {
  $('status').textContent = m;
  $('status').className = `status ${k}`;
  $('status').hidden = !m;
  if (p !== null) {
    $('progress').style.width = `${p}%`;
    $('progressTrack').setAttribute('aria-valuenow', String(p));
  }
};

async function api(path, opts = {}) {
  if (!settings.apiKey) throw new Error('Add your TalentOS API key in settings.');
  const res = await fetch(`${settings.baseUrl}${path}`, { cache: 'no-store', ...opts, headers: {
    'Content-Type': 'application/json', Authorization: `Bearer ${settings.apiKey}`,
    'X-TalentOS-Client': 'job-capture-extension/1.4.6', ...(opts.headers || {}) } });
  const b = await res.json().catch(() => ({}));
  if (!res.ok) {
    const e = new Error(b?.error?.message || b?.error || `HTTP ${res.status}`);
    e.code = b?.error?.code; e.details = b?.error?.details;
    throw e;
  }
  return b;
}

async function send(action, payload = {}) {
  try { return await chrome.tabs.sendMessage(tab.id, { action, ...payload }); }
  catch {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
    return chrome.tabs.sendMessage(tab.id, { action, ...payload });
  }
}

async function captureWithPermissions(mode) {
  try {
    if (!tab?.url || !/^https?:/.test(tab.url)) throw new Error('Open a job posting first.');
    const origins = [...new Set([new URL(tab.url).origin + '/*', new URL(settings.baseUrl).origin + '/*'])];
    const granted = await chrome.permissions.request({ origins });
    if (!granted) throw new Error('Allow access to this job site and TalentOS to capture the open page.');
    await capture(mode);
  } catch (e) { setStatus(e.message, 'error', 0); }
}

async function capture(mode) {
  currentJob = null; currentJobId = null; currentEligibility = null;
  pickerCandidates = []; assignmentOwners = []; assignedByLabel = ''; defaultOwnerUserId = '';
  draftCandidate = null; selectedCandidates = []; activeCandidateSelectionId = ''; candidateListGeneration++; assignmentStatus = 'assigned'; assignmentDueAt = ''; assignmentNote = '';
  candidateLookupGeneration++;
  $('matchResults').replaceChildren(); $('matchResults').style.display = 'none'; $('logSelected').style.display = 'none';
  $('eligibilityPrompt').style.display = 'none';
  $('openLink').style.display = 'none';
  const captureTab = { id: tab.id, url: tab.url };
  setStatus('Capturing…', '', 10);
  try {
    const r = await send('captureNow', { mode });
    if (tab.id !== captureTab.id || tab.url !== captureTab.url) return;
    if (!r?.ok) throw new Error(r?.error || 'Capture failed');

    if (r.mode === 'cards') {
      if (!r.cards.length) { setStatus('No job cards found on this page.', 'error', 0); return; }
      setStatus(`Sending ${r.cards.length} jobs…`, '', 70);
      let ok = 0, dup = 0, failed = 0, skipped = 0;
      for (const card of r.cards) {
        let c = card;
        try {
          if (c.needsRecovery || !c.jdText) {
            setStatus(`Reading full job ${ok + dup + failed + skipped + 1} of ${r.cards.length}...`, '', 70);
            const detail = await chrome.runtime.sendMessage({ action: 'captureJobPage', url: c.applyUrl });
            if (!detail?.ok || !detail.job?.company || (detail.job.jdText || '').trim().length < 150) throw new Error(detail?.error || 'Open the full posting to review its details.');
            c = { ...c, ...detail.job };
          }
          const res = await api('/api/extension/v1/capture-job', { method: 'POST',
            headers: { 'Idempotency-Key': c.idempotencyKey }, body: JSON.stringify(c) });
          res.duplicate ? dup++ : ok++;
        } catch (e) {
          if (e.code === 'eligibility_ack_required') {
            const restriction = e.details || {};
            const kinds = [
              restriction.requiresCitizenship && `Citizenship requirement${restriction.citizenshipCountries?.length ? ` (${restriction.citizenshipCountries.join(', ')})` : ''}`,
              restriction.exportControlRestricted && 'Security clearance or export-control restriction',
            ].filter(Boolean).join('; ');
            const proceed = confirm(`${c.title || 'This job'}${c.company ? ` at ${c.company}` : ''} has a hiring restriction: ${kinds || 'eligibility restriction detected'}${restriction.evidence ? `\n\nEvidence: ${restriction.evidence}` : ''}\n\nDo you want to add this job?`);
            if (!proceed) { skipped++; continue; }
            try {
              const res = await api('/api/extension/v1/capture-job', { method: 'POST',
                headers: { 'Idempotency-Key': c.idempotencyKey }, body: JSON.stringify({ ...c, acknowledgeEligibility: true }) });
              res.duplicate ? dup++ : ok++;
            } catch (retryError) { failed++; console.warn('card retry failed', c.title, retryError.message); }
          } else {
            failed++; console.warn('card failed', c.title, e.message);
          }
        }
      }
      setStatus(`Saved ${ok} new, ${dup} already known${skipped ? `, ${skipped} restricted jobs skipped` : ''}${failed ? `, ${failed} failed (some cards need the full job page)` : ''}.`, failed ? 'error' : 'success', 100);
      return;
    }

    const j = r.job;
    $('preview').textContent = `${j.title || '(no title)'} — ${j.company || '(no company)'} · ${(j.jdText || '').length} chars · ${j.confidence}%`;
    const missing = [!j.title && 'job title', !j.company && 'employer name', (j.jdText || '').trim().length < 150 && 'full job description'].filter(Boolean);
    if (missing.length) {
      throw new Error(`The posting has not loaded enough job details to capture. Missing: ${missing.join(', ')}. Refresh the full job page and capture again.`);
    }
    await submitSingleJob(j, $('matchCandidates').checked, false);
  } catch (e) { setStatus(e.message, 'error', 0); }
}

async function submitSingleJob(job, matchCandidates, acknowledged) {
  const captureContext = { tabId: tab?.id, url: tab?.url };
  currentJob = job;
  setStatus('Sending to TalentOS…', '', 65);
  const path = matchCandidates ? '/api/extension/v1/job-workflow' : '/api/extension/v1/capture-job';
  try {
    const res = await api(path, { method: 'POST', headers: { 'Idempotency-Key': job.idempotencyKey || crypto.randomUUID() },
      body: JSON.stringify({ ...job, matchCandidates, acknowledgeEligibility: acknowledged }) });
    if (tab?.id !== captureContext.tabId || tab?.url !== captureContext.url) return;
    currentJobId = res.jobId;
    currentEligibility = res.eligibility || null;
    const inactive = res.jobStatus?.state === 'inactive';
    setStatus(inactive ? 'This job already exists but is inactive in TalentOS. Its source posting status has not been verified. Open the record to review it.' : res.duplicate ? (res.jobStatus?.state === 'active' ? 'This job is already in TalentOS and is active in TalentOS.' : 'This job is already in TalentOS. Its status has not been verified.') : (res.jobStatus?.state === 'active' ? 'Job added and active in TalentOS.' : 'Job added to TalentOS.'), inactive ? 'error' : 'success', 100);
    $('openLink').style.display = 'flex';
    $('openLink').onclick = () => chrome.runtime.sendMessage({ action: 'openTalentOsJob', jobId: res.jobId, baseUrl: settings.baseUrl });
    if (matchCandidates && !inactive) await loadCandidatePicker();
  } catch (e) {
    if (e.code === 'eligibility_ack_required') {
      showEligibilityPrompt(e.details || {}, () => submitSingleJob(job, matchCandidates, true));
      setStatus('Review the eligibility restriction before continuing.', 'error', 45);
      return;
    }
    throw e;
  }
}

function showEligibilityPrompt(details, onYes) {
  const labels = [];
  if (details.requiresCitizenship) labels.push(`Citizenship requirement${details.citizenshipCountries?.length ? `: ${details.citizenshipCountries.join(', ')}` : ''}`);
  if (details.exportControlRestricted) labels.push('Export control or security-clearance requirement');
  $('eligibilityText').textContent = `${labels.join('. ') || 'A hiring eligibility restriction'} was detected. ${details.evidence || 'Review the job description and decide whether to proceed.'}`;
  $('eligibilityPrompt').style.display = 'block';
  $('confirmEligibility').onclick = async () => {
    $('eligibilityPrompt').style.display = 'none';
    try { await onYes(); } catch (e) { setStatus(e.message, 'error', 0); }
  };
  $('cancelEligibility').onclick = () => {
    $('eligibilityPrompt').style.display = 'none';
    setStatus('Cancelled. No further changes were made.', '', 0);
  };
}

function resumeLabel(resume) {
  const score = resume.scoreType === 'local_resume_relevance'
    ? `Local relevance ${resume.score ?? 0} pts`
    : resume.score === null ? 'No score' : `Approved match ${resume.score}/100${resume.tier ? ` | Tier ${resume.tier}` : ' | Review'}`;
  return `${resume.talentOsDefault ? 'TalentOS default | ' : ''}${resume.baseResumeName} | ${score}`;
}

function pickerField(label, control) {
  const wrap = document.createElement('label'); wrap.className = 'picker-field';
  const title = document.createElement('span'); title.textContent = label;
  wrap.append(title, control); return wrap;
}

function populateCandidateSelect(select) {
  select.replaceChildren();
  const placeholder = document.createElement('option'); placeholder.value = ''; placeholder.textContent = 'Select an active candidate...'; select.append(placeholder);
  for (const candidate of pickerCandidates) {
    const option = document.createElement('option'); option.value = candidate.candidateId;
    option.textContent = `${candidate.candidateName} | ${candidate.alreadyLogged ? 'Already logged to this job' : candidate.pipelineStage === 'applying' ? 'Actively applying' : 'Not started'}`;
    option.disabled = candidate.alreadyLogged || selectedCandidates.some((item) => item.candidateId === candidate.candidateId);
    select.append(option);
  }
  if (!pickerCandidates.length) {
    const empty = document.createElement('option'); empty.disabled = true; empty.textContent = 'No active candidates with base resumes are available'; select.append(empty);
  }
  select.value = activeCandidateSelectionId;
}

async function refreshCandidateOptions({ preserveStatus = false } = {}) {
  if (!currentJobId) return;
  const generation = ++candidateListGeneration;
  const select = $('candidateSelect');
  const feedback = $('candidateListFeedback');
  if (select) select.disabled = true;
  if (feedback) feedback.textContent = 'Refreshing active candidates…';
  try {
    const query = new URLSearchParams({ jobId: currentJobId });
    const data = await api('/api/extension/v1/job-workflow?' + query.toString());
    if (generation !== candidateListGeneration) return;
    currentJobId = data.jobId || currentJobId;
    pickerCandidates = data.candidates || [];
    if (select) { populateCandidateSelect(select); select.disabled = false; }
    if (feedback) {
      const alreadyLogged = pickerCandidates.filter((candidate) => candidate.alreadyLogged).length;
      feedback.textContent = pickerCandidates.length + ' active candidate' + (pickerCandidates.length === 1 ? '' : 's') + ' shown.' + (alreadyLogged ? ' ' + alreadyLogged + ' already logged to this job and cannot be selected again.' : '');
    }
    const foot = $('matchResults').querySelector('.picker-footnote');
    if (foot) foot.textContent = 'The default resume follows TalentOS approved-resume domain matching; other options remain selectable. This uses no AI tokens.';
  } catch (e) {
    if (generation !== candidateListGeneration) return;
    if (select) select.disabled = false;
    if (feedback) feedback.textContent = 'Could not refresh candidates: ' + (e.message || 'Please try again.');
    if (!preserveStatus) setStatus(e.message || 'Could not refresh active candidates.', 'error', 100);
  }
}
function renderCandidatePicker(message = '') {
  const root = $('matchResults'); root.replaceChildren(); root.style.display = 'block';
  const heading = document.createElement('div'); heading.className = 'picker-heading'; heading.textContent = 'Choose candidates for this job';
  const help = document.createElement('p'); help.className = 'meta picker-help';
  help.textContent = 'All active candidates with base resumes are listed. Already logged candidates remain visible but cannot be selected again. TalentOS preselects a base resume; you can change it anytime.';
  root.append(heading, help);
  if (message) { const notice = document.createElement('div'); notice.className = 'picker-notice'; notice.textContent = message; root.append(notice); }

  const candidateSelect = document.createElement('select'); candidateSelect.id = 'candidateSelect'; candidateSelect.setAttribute('aria-label', 'Choose active candidate');
  populateCandidateSelect(candidateSelect);
  candidateSelect.addEventListener('change', () => { activeCandidateSelectionId = candidateSelect.value; loadCandidateResumeOptions(candidateSelect.value); });
  root.append(pickerField('Candidate', candidateSelect));
  const alreadyLoggedCount = pickerCandidates.filter((candidate) => candidate.alreadyLogged).length;
  const listFeedback = document.createElement('div'); listFeedback.className = 'picker-list-feedback'; listFeedback.id = 'candidateListFeedback';
  listFeedback.textContent = pickerCandidates.length + ' active candidate' + (pickerCandidates.length === 1 ? '' : 's') + ' shown.' + (alreadyLoggedCount ? ' ' + alreadyLoggedCount + ' already logged to this job and cannot be selected again.' : '');
  root.append(listFeedback);

  if (draftCandidate) {
    const draft = document.createElement('div'); draft.className = 'candidate-card draft-card';
    const title = document.createElement('strong'); title.className = 'candidate-card-title';
    title.textContent = `${draftCandidate.candidateName} | ${draftCandidate.resumeOptions.length} base resume${draftCandidate.resumeOptions.length === 1 ? '' : 's'}`;
    const resumeSelect = document.createElement('select'); resumeSelect.id = 'draftResumeSelect';
    resumeSelect.setAttribute('aria-label', `Base resume for ${draftCandidate.candidateName}`);
    for (const resume of draftCandidate.resumeOptions) { const option = document.createElement('option'); option.value = resume.baseResumeId; option.textContent = resumeLabel(resume); resumeSelect.append(option); }
    resumeSelect.value = draftCandidate.selectedResumeId;
    resumeSelect.addEventListener('change', () => { draftCandidate.selectedResumeId = resumeSelect.value; renderCandidatePicker(); });
    const picked = draftCandidate.resumeOptions.find((resume) => resume.baseResumeId === draftCandidate.selectedResumeId);
    const reason = document.createElement('div'); reason.className = picked?.recommended || picked?.talentOsDefault ? 'match-meta score-good' : 'match-meta score-review';
    reason.textContent = picked?.reason || 'No match details are available.';
    const add = document.createElement('button'); add.type = 'button'; add.className = 'button button-secondary add-candidate'; add.textContent = 'Add candidate';
    add.addEventListener('click', () => { if (!draftCandidate) return; selectedCandidates.push({ ...draftCandidate }); draftCandidate = null; activeCandidateSelectionId = ''; renderCandidatePicker(); });
    draft.append(title, pickerField('Selected base resume', resumeSelect), reason, add); root.append(draft);
  }

  if (selectedCandidates.length) { const sub = document.createElement('div'); sub.className = 'picker-subheading'; sub.textContent = `Selected candidates (${selectedCandidates.length})`; root.append(sub); }
  for (const selected of selectedCandidates) {
    const card = document.createElement('div'); card.className = 'candidate-card';
    const title = document.createElement('strong'); title.className = 'candidate-card-title'; title.textContent = selected.candidateName;
    const remove = document.createElement('button'); remove.type = 'button'; remove.className = 'remove-candidate'; remove.textContent = 'Remove';
    remove.addEventListener('click', () => { selectedCandidates = selectedCandidates.filter((item) => item.candidateId !== selected.candidateId); renderCandidatePicker(); });
    const cardHead = document.createElement('div'); cardHead.className = 'candidate-card-head'; cardHead.append(title, remove);
    const resumeSelect = document.createElement('select'); resumeSelect.setAttribute('aria-label', `Base resume for ${selected.candidateName}`);
    for (const resume of selected.resumeOptions) { const option = document.createElement('option'); option.value = resume.baseResumeId; option.textContent = resumeLabel(resume); resumeSelect.append(option); }
    resumeSelect.value = selected.selectedResumeId;
    resumeSelect.addEventListener('change', () => { selected.selectedResumeId = resumeSelect.value; renderCandidatePicker(); });
    const picked = selected.resumeOptions.find((resume) => resume.baseResumeId === selected.selectedResumeId);
    const reason = document.createElement('div'); reason.className = picked?.recommended || picked?.talentOsDefault ? 'match-meta score-good' : 'match-meta score-review'; reason.textContent = picked?.reason || 'No match details are available.';
    card.append(cardHead, pickerField('Base resume', resumeSelect), reason); root.append(card);
  }

  const sub = document.createElement('div'); sub.className = 'picker-subheading'; sub.textContent = 'Application workflow'; root.append(sub);
  const status = document.createElement('select'); status.id = 'assignmentStatus';
  for (const [value, label] of [['stacked', 'Stacked'], ['assigned', 'Assigned to apply'], ['in_progress', 'In progress']]) { const option = document.createElement('option'); option.value = value; option.textContent = label; status.append(option); }
  status.value = assignmentStatus; status.addEventListener('change', () => { assignmentStatus = status.value; });
  const assignedBy = document.createElement('input'); assignedBy.value = assignedByLabel; assignedBy.readOnly = true;
  const owner = document.createElement('select'); owner.id = 'assignmentOwner';
  for (const member of assignmentOwners) { const option = document.createElement('option'); option.value = member.userId; option.textContent = `${member.name}${member.role === 'application_engineer' ? ' | Application Engineer' : ''}`; owner.append(option); }
  owner.value = defaultOwnerUserId; owner.addEventListener('change', () => { defaultOwnerUserId = owner.value; });
  const due = document.createElement('input'); due.id = 'assignmentDueAt'; due.type = 'date'; due.value = assignmentDueAt; due.addEventListener('change', () => { assignmentDueAt = due.value; });
  const note = document.createElement('textarea'); note.id = 'assignmentNote'; note.rows = 3; note.maxLength = 2000; note.placeholder = 'Instructions, candidate context, resume choice, etc.'; note.value = assignmentNote; note.addEventListener('input', () => { assignmentNote = note.value; });
  const grid = document.createElement('div'); grid.className = 'workflow-grid'; grid.append(pickerField('Status', status), pickerField('Assigned by', assignedBy), pickerField('Application owner', owner), pickerField('Due date', due));
  root.append(grid, pickerField('Assignment note', note));
  const foot = document.createElement('div'); foot.className = 'meta picker-footnote';
  foot.textContent = 'Approved profiles use TalentOS match scores. Other resumes use a local relevance estimate; neither action starts an AI call.'; root.append(foot);
  $('logSelected').style.display = selectedCandidates.length ? 'flex' : 'none';
  $('logSelected').textContent = selectedCandidates.length ? `Log job to ${selectedCandidates.length} candidate${selectedCandidates.length === 1 ? '' : 's'}` : 'Log job to selected candidates';
  $('logSelected').onclick = logSelectedCandidates;
}

async function loadCandidatePicker() {
  const root = $('matchResults'); root.style.display = 'block'; root.replaceChildren();
  const loading = document.createElement('div'); loading.className = 'meta'; loading.textContent = 'Loading active candidates and application owners...'; root.append(loading);
  $('logSelected').style.display = 'none';
  try {
    const requestedJobId = currentJobId;
    const data = await api(`/api/extension/v1/job-workflow?jobId=${encodeURIComponent(requestedJobId)}`);
    if (currentJobId !== requestedJobId) return;
    currentJobId = data.jobId || currentJobId;
    pickerCandidates = data.candidates || []; assignmentOwners = data.owners || [];
    assignedByLabel = data.assignedBy || ''; defaultOwnerUserId = data.defaultOwnerUserId || assignmentOwners[0]?.userId || '';
    activeCandidateSelectionId = '';
    renderCandidatePicker(pickerCandidates.length ? '' : 'No active candidates with base resumes are available. Check candidate status and resume records in TalentOS.');
  } catch (e) { renderCandidatePicker(e.message || 'Could not load candidates.'); setStatus(e.message, 'error', 100); }
}

let candidateLookupGeneration = 0;
async function loadCandidateResumeOptions(candidateId) {
  draftCandidate = null; renderCandidatePicker();
  const generation = ++candidateLookupGeneration;
  if (!candidateId) return;
    setStatus('Comparing this candidate’s base resumes…', '', 100);
  try {
    const data = await api(`/api/extension/v1/job-workflow?jobId=${encodeURIComponent(currentJobId)}&candidateId=${encodeURIComponent(candidateId)}`);
    if (generation !== candidateLookupGeneration || $('candidateSelect')?.value !== candidateId) return;
    draftCandidate = { ...data.candidate, selectedResumeId: data.candidate.bestResumeId };
    renderCandidatePicker(); setStatus('Best available base resume selected. Review or change it, then add the candidate.', 'success', 100);
  } catch (e) {
    if (generation !== candidateLookupGeneration) return;
    renderCandidatePicker(e.message || 'Could not load this candidate base resumes.'); setStatus(e.message, 'error', 100);
  }
}

async function logSelectedCandidates() {
  if (!selectedCandidates.length) { setStatus('Select at least one candidate first.', 'error', 100); return; }
  const selections = selectedCandidates.map((candidate) => ({ candidateId: candidate.candidateId, baseResumeId: candidate.selectedResumeId }));
  $('logSelected').disabled = true;
  setStatus(`Submitting ${selections.length} candidate${selections.length === 1 ? '' : 's'} for review...`, '', 75);
  try {
    // Fail closed against a backend that still has the old direct-to-pipeline
    // assign endpoint. This read-only check never creates an application.
    const workflow = await api(`/api/extension/v1/job-workflow?jobId=${encodeURIComponent(currentJobId)}`);
    if (workflow.assignmentMode !== 'human_review') {
      throw new Error('This TalentOS server has not enabled human review for extension submissions yet. Nothing was submitted. Deploy the Review Queue backend before trying again.');
    }
    currentJobId = workflow.jobId || currentJobId;
    const result = await api('/api/extension/v1/job-workflow', { method: 'POST', headers: { 'Idempotency-Key': crypto.randomUUID() },
      body: JSON.stringify({ action: 'assign', jobId: currentJobId, selections, assignmentStatus,
        assignedToUserId: $('assignmentOwner')?.value || defaultOwnerUserId,
        assignmentDueAt: $('assignmentDueAt')?.value || null, assignmentNote: $('assignmentNote')?.value || '',
        acknowledgeEligibility: !!currentEligibility?.eligibilityRestricted }) });
    if (result.assignmentMode !== 'human_review' || result.results.some((x) => x.status === 'logged')) {
      throw new Error('The server returned a legacy direct-logging response. Human review was not confirmed; check TalentOS before retrying this job.');
    }
    const submitted = result.results.filter((x) => x.status === 'submitted_for_review').length;
    const failed = result.results.filter((x) => x.status === 'failed').length;
    const already = result.results.filter((x) => x.status === 'already_logged' || x.status === 'already_pending_review').length;
    const details = result.results.map((x) => {
      if (x.status === 'already_logged') return `${x.candidateName || x.candidateId}: ${x.message || 'already logged to this job; no duplicate was created'}`;
      if (x.status === 'already_pending_review') return `${x.candidateName || x.candidateId}: ${x.message || 'already pending review for this job'}`;
      if (x.status === 'submitted_for_review') return `${x.candidateName || x.candidateId}: submitted for review${x.aiStatus === 'pending' ? ` (${x.atsScore != null ? `ATS score: ${x.atsScore}, ` : ''}AI scoring queued)` : x.aiRecommendation === 'reject' ? ' (AI: not recommended; awaiting human decision)' : x.aiTier ? ` (AI tier: ${x.aiTier})` : x.aiStatus === 'scored' ? ` (AI reviewed${x.aiScore != null ? `: ${x.aiScore}` : ''})` : x.atsScore != null ? ` (ATS score: ${x.atsScore}, AI check pending/unavailable)` : ''}`;
      return `${x.candidateName || x.candidateId}: ${x.status}${x.error ? ` | ${x.error}` : ''}`;
    }).join(' | ');
    const completedIds = new Set(result.results.filter((x) => x.status === 'submitted_for_review' || x.status === 'already_logged' || x.status === 'already_pending_review').map((x) => x.candidateId));
    selectedCandidates = selectedCandidates.filter((candidate) => !completedIds.has(candidate.candidateId));
    draftCandidate = null;
    activeCandidateSelectionId = '';
    if (!failed) {
      assignmentStatus = 'assigned';
      assignmentDueAt = '';
      assignmentNote = '';
    }
    // Disable completed pairs locally before the optional background refresh.
    pickerCandidates = pickerCandidates.map(candidate => completedIds.has(candidate.candidateId) ? { ...candidate, alreadyLogged: true } : candidate);
    renderCandidatePicker();
    const summary = `Finished: ${submitted} submitted for review, ${already} already logged/pending, ${failed} failed.`;
    setStatus(`${summary}${details ? ` ${details}` : ''}`, failed ? 'error' : 'success', 100);
    $('status').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    void refreshCandidateOptions({ preserveStatus: true });
  } catch (e) {
    if (e.code === 'eligibility_ack_required') { showEligibilityPrompt(e.details || {}, logSelectedCandidates); setStatus('Confirm this restriction before logging candidates.', 'error', 75); }
    else setStatus(e.message, 'error', 75);
    $('status').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  } finally { $('logSelected').disabled = false; }
}

chrome.runtime.onMessage.addListener((m) => {
  if (m.action === 'captureProgress') setStatus(m.detail || m.message, m.status === 'failed' ? 'error' : '', m.percent);
});

async function refresh() {
  const previousTab = tab;
  [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (previousTab && (previousTab.id !== tab?.id || previousTab.url !== tab?.url)) {
    currentJob = null; currentJobId = null; currentEligibility = null; selectedCandidates = []; draftCandidate = null; candidateLookupGeneration++; candidateListGeneration++;
    $('eligibilityPrompt').style.display = 'none';
    $('matchResults').replaceChildren(); $('logSelected').style.display = 'none'; $('openLink').style.display = 'none'; setStatus('');
  }
  if (!tab || !/^https?:/.test(tab.url || '')) {
    $('pageTitle').textContent = 'No page open';
    $('hint').textContent = 'Open a job posting or job search page first.';
    $('captureBtn').disabled = true;
    return;
  }
  $('captureBtn').disabled = false;
  $('pageTitle').textContent = tab?.title || '—';
  try { const d = await send('detectPage'); kind = d?.kind || 'single'; hasOpenJob = !!d?.hasOpenJob; } catch { kind = 'single'; hasOpenJob = false; }
  const captureOpenJob = kind !== 'search' || hasOpenJob;
  $('captureBtn').textContent = captureOpenJob ? 'Capture This Job' : 'Capture All Results';
  $('altBtn').textContent = hasOpenJob ? 'Capture All Results' : 'Capture open job from results';
  $('altBtn').style.display = kind === 'search' ? 'flex' : 'none';
  $('matchOption').style.display = 'flex';
  $('hint').textContent = kind === 'search' && !hasOpenJob ? 'Search page — capture all results, or capture the open job to choose candidates.' : 'Job page — full capture.';
}

$('captureBtn').onclick = () => captureWithPermissions(kind === 'search' && !hasOpenJob ? 'cards' : 'single');
$('altBtn').onclick = () => captureWithPermissions(hasOpenJob ? 'cards' : 'single');   // capture just the open detail pane
$('openSettings').onclick = () => chrome.runtime.openOptionsPage();
chrome.tabs.onActivated.addListener(refresh);
chrome.tabs.onUpdated.addListener((_i, c, t) => { if (t.active && (c.url || c.status === 'complete')) refresh(); });
chrome.storage.local.get(['settings']).then((s) => {
  settings = { baseUrl: s.settings?.baseUrl || DEFAULT_URL, apiKey: s.settings?.apiKey || DEFAULT_API_KEY };
  refresh();
});
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== 'local' || !changes.settings?.newValue) return;
  settings = { baseUrl: changes.settings.newValue.baseUrl || DEFAULT_URL, apiKey: changes.settings.newValue.apiKey || '' };
});

