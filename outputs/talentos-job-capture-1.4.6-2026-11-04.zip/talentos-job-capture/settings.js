const DEFAULT_URL = 'https://talent.skarion.com';
const $ = (id) => document.getElementById(id);

function showStatus(message, kind) {
  const status = $('settingsStatus');
  status.textContent = message;
  status.className = `settings-status ${kind}`;
  status.hidden = false;
  status.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

chrome.storage.local.get(['settings']).then(({ settings }) => {
  $('baseUrl').value = settings?.baseUrl || DEFAULT_URL;
  $('apiKey').value = settings?.apiKey || '';
});

$('settingsForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const baseUrl = $('baseUrl').value.trim().replace(/\/+$/, '');
  const apiKey = $('apiKey').value.trim();
  let parsed;
  try { parsed = new URL(baseUrl); }
  catch { showStatus('Enter a valid TalentOS server address.', 'error'); return; }
  if (!['https:', 'http:'].includes(parsed.protocol)) {
    showStatus('The server address must use HTTP or HTTPS.', 'error');
    return;
  }
  if (!apiKey) { showStatus('Enter the API key issued to your team member profile.', 'error'); return; }

  $('saveSettings').disabled = true;
  try {
    const granted = await chrome.permissions.request({ origins: [parsed.origin + '/*'] });
    if (!granted) throw new Error('Allow access to the TalentOS server to save this connection.');
    await chrome.storage.local.set({ settings: { baseUrl, apiKey } });
    showStatus('Connection saved. The extension panel will use these settings now.', 'success');
  } catch (error) {
    showStatus(`Could not save settings: ${error.message || 'browser storage is unavailable.'}`, 'error');
  } finally {
    $('saveSettings').disabled = false;
  }
});
