# TalentOS Job Capture 1.4.6

1.4.6 reads SmartRecruiters' nested employer metadata and skips hidden browser-warning headings. SmartRecruiters and Workable capture waits up to six seconds for job content to hydrate. LinkedIn expands only a visible description button, never a social or navigation anchor; it preserves the selected posting's numeric canonical URL, excludes other jobs' structured data, and rejects a selection that changes during capture. Candidate submission displays its result as soon as the assignment response arrives, refreshes candidates in the background, and reports pending background AI as "AI scoring queued". A failed candidate refresh leaves the submission result visible. Reload the unpacked extension and refresh job tabs after updating.

The additional fixture regressions live outside the distributable in `../tests/job-capture-regressions.cjs`. The existing browser suite runs them in its single Chromium instance; they can also run directly from the TalentOS checkout with `node ../Extensions/TalentOS-Extensions/tests/job-capture-regressions.cjs`. Every portal/API request is intercepted. These fixtures reproduce the reported layouts; this patch has not automated the user's live browser or called production APIs.

1.4.5 fixes Indeed's non-linked `vj-company-name` employer field, ZIP/ZIP+4 and neighborhood locations, remote location labels, decimal pay ranges, and full-time/part-time labels in the job header. Missing-field errors now identify which job information could not be read. Reload the unpacked extension and refresh existing job tabs after updating. Candidate submission still requires the same human-review contract.

The employer marker and location were verified on live Indeed job `959625adfa94adc2` after the user completed Indeed verification. Browser fixtures reproduce that inspected header and the AXNT screenshot variant. Automated tests load the actual unpacked extension, intercept TalentOS requests, and verify capture, candidate/resume selection, and human-review submission without creating production jobs or applications. The installed Chrome UI test could not be completed because computer-use safety controls could not verify the browser URL. The portal extraction fixes work with the existing backend; faster submission with background AI requires backend migration 133 and deployment of the matching backend changes.

Load this folder using Chrome's **Extensions → Developer mode → Load unpacked**, or reload the existing unpacked extension after replacing its files. Refresh open job tabs after reloading. Deploy the accompanying TalentOS backend changes before using duplicate-to-original job resolution.

Candidate submissions require the backend's `human_review` contract. With backend migration 133 and the matching deployment: capture → select candidate and base resume → submit → ATS scoring → pending Review Queue → background AI scoring → admin/manager approval → application and resume pipeline. Submission returns after the pair is queued; pending background AI is shown as "AI scoring queued". An unavailable AI check leaves the ATS-scored pair pending human review. A server still running the old direct-to-pipeline endpoint is blocked before submission, and legacy `logged` responses are never reported as pending human approval. The portal extraction fixes remain usable on the existing human-review backend; the submission speed improvement requires migration 133 and the matching backend deployment.

Every valid candidate/job pairing selected in the extension reaches human review regardless of its ATS score, including 0%, or an AI recommendation against the pairing. Scores and warnings are shown to the reviewer; neither starts an application. Existing duplicate protection remains in place. The scheduled batch workflow keeps its configured ATS floor.

Open extension settings, enter the TalentOS server address and your own extension API key, and save. The default server is `https://talent.skarion.com`. Capture requests browser access to the current job site and configured TalentOS server. Additional employer and regional job sites use optional browser site permissions.

Indeed reads both classic company-name headers and the current desktop-job-header/company-info-metadata profile link, plus its adjacent location and salary. It never uses a navigation text line as the employer. Glassdoor has its own details adapter. Structured JobPosting data supports nested graphs and type arrays across ATS and employer sites. The capture controls are preserved: capture → save or find the existing job → choose candidates and base resumes → submit for human approval. There is no additional information review form in the extension. LinkedIn reads current and classic headers, company links, accessible labels, title metadata, explicitly labeled company descriptions, and public posting markup when fields are missing. Sign-in and site verification must be completed in the job tab before capture. If essential job details remain unavailable after automatic recovery, capture reports an error rather than saving an invented employer or an empty description.

Bulk capture opens each posting sequentially in a temporary inactive tab to read its full description using the existing browser session, then closes that tab. Sites without permission or readable posting details are reported as failed and can be captured individually. No blank description is silently saved.

On search pages with a job open in a detail pane, the primary action captures that selected job and the candidate option stays visible. Bulk capture is available as the secondary action. This covers Glassdoor recommendation/search pages as well as the existing single-job flow.

Hidden duplicate copies resolve to the original TalentOS job for candidate selection and assignment. “Active in TalentOS” describes the stored job's internal status; it does not claim that a third-party posting's live availability has been checked. Deliberately inactive jobs remain inactive.

Run browser regression fixtures from the TalentOS checkout (requires its Playwright dependency and Chromium):

```powershell
node ../Extensions/TalentOS-Extensions/talentos-job-capture/tests/capture-browser.cjs
```

The fixtures cover Indeed, Glassdoor, LinkedIn, several ATS/board hosts, permission denial, verification pages, duplicate resolution in the panel, automatic LinkedIn company recovery, and the complete capture-and-assign flow without extra information fields. They do not establish that every live job site's future layouts will remain compatible.

For a test using the actual unpacked extension, not a chrome API stub:

```powershell
node ../Extensions/TalentOS-Extensions/talentos-job-capture/tests/loaded-extension.cjs
```

This launches a temporary Chromium profile, loads this manifest/content script/background worker/panel, intercepts portal HTML and TalentOS API traffic, and tests 14 portal host configurations. The Indeed and Glassdoor panel cases exercise capture, canonical duplicate handling, resume/owner selection, and candidate logging. No production application is created. The regression suite additionally covers current Indeed and Glassdoor DOM variants, selected jobs within search results, authentication walls, and explicitly expired postings.

Live DOM checks for this update used Indeed job `ee3bac34a204c34f`, a Glassdoor selected detail pane, and a current plus an expired Dice posting. These do not establish universal compatibility with every live posting or with future site changes. Login and verification pages must be completed in the user's browser before capture.
