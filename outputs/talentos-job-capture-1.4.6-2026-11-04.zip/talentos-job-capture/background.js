const TALENTOS_ORIGINS = new Set(['https://talent.skarion.com', 'https://skarion-talent-os.skarion-talentos.workers.dev']);

chrome.runtime.onMessage.addListener((m) => {
  if (m.action !== 'captureProgress') return;
  const map = { running: ['…', '#0a66c2'], failed: ['!', '#b91c1c'], complete: ['✓', '#057642'] };
  const [t, c] = map[m.status] || ['', '#666'];
  chrome.action.setBadgeText({ text: t });
  chrome.action.setBadgeBackgroundColor({ color: c });
});

async function openJob(jobId, baseUrl) {
  const path = `/jobs/${encodeURIComponent(jobId)}`;
  const tabs = await chrome.tabs.query({});
  const hit = tabs.filter((t) => { try { return TALENTOS_ORIGINS.has(new URL(t.url).origin); } catch { return false; } })
                  .sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0))[0];
  if (hit?.id) return chrome.tabs.update(hit.id, { url: new URL(hit.url).origin + path, active: true });
  return chrome.tabs.create({ url: baseUrl + path, active: true });
}

chrome.runtime.onMessage.addListener((m, _s, send) => {
  if (m.action !== 'openTalentOsJob') return false;
  openJob(m.jobId, m.baseUrl).then(() => send({ ok: true })).catch((e) => send({ ok: false, error: e.message }));
  return true;
});

const enable = () => chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(console.error);
chrome.runtime.onInstalled.addListener(enable);
chrome.runtime.onStartup.addListener(enable);
enable();

// Bulk capture reads full postings in the user's browser session instead of
// asking the API to save empty descriptions or scrape through a login wall.
async function captureJobPage(url) {
  const parsed = new URL(url);
  if (!['https:', 'http:'].includes(parsed.protocol)) throw new Error('Unsupported job URL.');
  if (!await chrome.permissions.contains({ origins: [parsed.origin + '/*'] })) throw new Error('Open this posting and grant site access before capturing it.');
  const jobTab = await chrome.tabs.create({ url: parsed.href, active: false });
  try {
    await new Promise((resolve, reject) => {
      const timeout = setTimeout(() => { chrome.tabs.onUpdated.removeListener(listener); reject(new Error('Job page did not finish loading. Open it and capture individually.')); }, 30000);
      const listener = (id, change) => { if (id === jobTab.id && change.status === 'complete') { clearTimeout(timeout); chrome.tabs.onUpdated.removeListener(listener); resolve(); } };
      chrome.tabs.onUpdated.addListener(listener);
      chrome.tabs.get(jobTab.id).then((t) => { if (t.status === 'complete') listener(t.id, { status: 'complete' }); }).catch(reject);
    });
    await chrome.scripting.executeScript({ target: { tabId: jobTab.id }, files: ['content.js'] });
    return await chrome.tabs.sendMessage(jobTab.id, { action: 'captureNow', mode: 'single' });
  } finally { await chrome.tabs.remove(jobTab.id).catch(() => {}); }
}
chrome.runtime.onMessage.addListener((message, _sender, send) => {
  if (message.action !== 'captureJobPage') return false;
  captureJobPage(message.url).then(send).catch((error) => send({ ok: false, error: error.message }));
  return true;
});
