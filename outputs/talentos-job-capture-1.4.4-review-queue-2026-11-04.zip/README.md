# TalentOS Job Capture 1.4.4

Load this folder using Chrome's **Extensions → Developer mode → Load unpacked**, or reload the existing unpacked extension after replacing its files. Refresh open job tabs after reloading. Deploy the accompanying TalentOS backend changes before using duplicate-to-original job resolution.

Candidate submissions now require the backend's `human_review` contract. Capture → select candidate and base resume → submit → ATS/AI scoring → pending Review Queue → admin/manager approval → application and resume pipeline. An unavailable AI check still queues an ATS-only item for a human to review. A server still running the old direct-to-pipeline endpoint is blocked before submission, and legacy `logged` responses are never reported as pending human approval. Deploy the matching backend before distributing this extension update.

Every valid candidate/job pairing selected in the extension reaches human review regardless of its ATS score, including 0%, or an AI recommendation against the pairing. Scores and warnings are shown to the reviewer; neither starts an application. Existing duplicate protection remains in place. The scheduled batch workflow keeps its configured ATS floor.

Open extension settings, enter the TalentOS server address and your own extension API key, and save. The default server is `https://talent.skarion.com`. Capture requests browser access to the current job site and configured TalentOS server. Additional employer and regional job sites use optional browser site permissions.

Indeed reads both classic company-name headers and the current desktop-job-header/company-info-metadata profile link, plus its adjacent location and salary. It never uses a navigation text line as the employer. Glassdoor has its own details adapter. Structured JobPosting data supports nested graphs and type arrays across ATS and employer sites. The capture controls are preserved: capture → save or find the existing job → choose candidates and base resumes → submit for human approval. There is no additional information review form in the extension. LinkedIn reads current and classic headers, company links, accessible labels, title metadata, explicitly labeled company descriptions, and public posting markup when fields are missing. Sign-in and site verification must be completed in the job tab before capture. If essential job details remain unavailable after automatic recovery, capture reports an error rather than saving an invented employer or an empty description.

Bulk capture opens each posting sequentially in a temporary inactive tab to read its full description using the existing browser session, then closes that tab. Sites without permission or readable posting details are reported as failed and can be captured individually. No blank description is silently saved.

On search pages with a job open in a detail pane, the primary action captures that selected job and the candidate option stays visible. Bulk capture is available as the secondary action. This covers Glassdoor recommendation/search pages as well as the existing single-job flow.

Hidden duplicate copies resolve to the original TalentOS job for candidate selection and assignment. “Active in TalentOS” describes the stored job's internal status; it does not claim that a third-party posting's live availability has been checked. Deliberately inactive jobs remain inactive.

Run browser regression fixtures from the TalentOS checkout (requires its Playwright dependency and Chromium):

```powershell
node ../Extensions/TalentOS-Extensions/talentos-job-capture/tests/capture-browser.cjs
```

The fixtures cover Indeed, Glassdoor, LinkedIn, several ATS/board hosts, permission denial, verification pages, duplicate resolution in the panel, automatic LinkedIn company recovery, and the complete capture-and-assign flow without extra information fields. They do not establish that every live job site's future layouts will remain compatible.

For a test using the actual unpacked extension, not a chrome API stub:

```powershell
node ../Extensions/TalentOS-Extensions/talentos-job-capture/tests/loaded-extension.cjs
```

This launches a temporary Chromium profile, loads this manifest/content script/background worker/panel, intercepts portal HTML and TalentOS API traffic, and tests 14 portal host configurations. The Indeed and Glassdoor panel cases exercise capture, canonical duplicate handling, resume/owner selection, and candidate logging. No production application is created. The regression suite additionally covers current Indeed and Glassdoor DOM variants, selected jobs within search results, authentication walls, and explicitly expired postings.

Live DOM checks for this update used Indeed job `ee3bac34a204c34f`, a Glassdoor selected detail pane, and a current plus an expired Dice posting. These do not establish universal compatibility with every live posting or with future site changes. Login and verification pages must be completed in the user's browser before capture.
