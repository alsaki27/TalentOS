// TalentOS Job Capture — content script
// MODE A (single job): JSON-LD → microdata → site adapter → generic brute force
// MODE B (search page): outermost-filtered card extraction + needsRecovery

if (window.__tosCapVersion !== chrome.runtime.getManifest().version) {
  window.__tosCapVersion = chrome.runtime.getManifest().version;
  window.__tosCapRunning = false;
  initTosCapture();
}

function initTosCapture() {
  const delay = (ms) => new Promise((r) => setTimeout(r, ms));
  const T = (e) => (e?.innerText || e?.textContent || '').trim();
  const clean = (s) => String(s || '').replace(/\s+/g, ' ').trim();
  const meta = (n, scope = document) => scope.querySelector(`meta[property="${n}"],meta[name="${n}"]`)?.content || '';

  const BAD_COMPANY = /^(home|sign in|log in|login|menu|jobs?|job search|search jobs|apply now|careers?|skip to (?:main )?content)$/i;
  const isJobBoard = /(^|\.)(indeed\.[a-z.]+|glassdoor\.[a-z.]+|linkedin\.com|ziprecruiter\.com|dice\.com|simplyhired\.[a-z.]+|hiring\.cafe|hiringcafe\.com)$/i.test(location.hostname);
  function employer(value) {
    const name = clean(value);
    if (!name || BAD_COMPANY.test(name)) return '';
    if (isJobBoard && /^(indeed(?:\.com)?|glassdoor(?:\.com)?|linkedin|ziprecruiter|dice|simplyhired|hiringcafe)$/i.test(name.replace(/\s/g, ''))) return '';
    return name;
  }
  function firstText(scope, selectors) {
    for (const selector of selectors) {
      const text = clean(T(scope.querySelector(selector)));
      if (text) return text;
    }
    return '';
  }
  function postingUrl() {
    const u = new URL(location.href);
    if (/indeed\./i.test(u.hostname) && (u.searchParams.get('vjk') || u.searchParams.get('jk'))) return `${u.origin}/viewjob?jk=${u.searchParams.get('vjk') || u.searchParams.get('jk')}`;
    if (/glassdoor\./i.test(u.hostname)) {
      const selected = document.querySelector('[id^="jd-job-title-"]')?.id.replace('jd-job-title-', '');
      const link = selected && document.getElementById('job-title-' + selected);
      if (link?.href) return link.href.split('#')[0];
      // Recommendation lists can virtualize away the selected card. The detail
      // header still carries the posting ID, so never save the generic search URL.
      if (/^\d+$/.test(selected || '')) return `${u.origin}/job-listing/j?jl=${selected}`;
    }
    if (/linkedin\.com$/i.test(u.hostname) && u.searchParams.get('currentJobId')) return `${u.origin}/jobs/view/${u.searchParams.get('currentJobId')}/`;
    return u.href.split('#')[0];
  }
  function jobPostings(scope = document) {
    const out = [];
    const visit = (x) => {
      if (!x || typeof x !== 'object') return;
      if (Array.isArray(x)) { x.forEach(visit); return; }
      if ([x['@type']].flat().includes('JobPosting')) out.push(x);
      for (const key of ['@graph', 'mainEntity', 'itemListElement', 'item']) visit(x[key]);
    };
    for (const sc of scope.querySelectorAll('script[type="application/ld+json"]')) {
      try { visit(JSON.parse(sc.textContent)); } catch { /* unrelated malformed data */ }
    }
    if (out.length <= 1) return out;
    const here = postingUrl();
    const id = new URL(here).searchParams.get('jk') || new URL(here).searchParams.get('jl') || here.match(/\/jobs\/view\/(?:[^/]*-)?(\d+)/)?.[1];
    return out.filter((x) => x.url && (x.url === here || (id && String(x.url).includes(id))));
  }

  // US states/territories plus common countries. Reference data answering one
  // question: does the text after the comma name a real region? That is what
  // separates a genuine "Austin, TX" from a fragment of the job description that
  // merely contains a comma. Unvalidated, the location regex below happily
  // reported "GitLab Runners, Azure" (lifted from a CI/CD tool list) as the job's
  // location, and TalentOS stored it as the city.
  const REGIONS = new Set(('al ak az ar ca co ct de fl ga hi id il in ia ks ky la me md ma mi mn ms mo mt ne nv nh ' +
    'nj nm ny nc nd oh ok or pa ri sc sd tn tx ut vt va wa wv wi wy dc pr vi gu ' +
    'alabama alaska arizona arkansas california colorado connecticut delaware florida georgia hawaii idaho ' +
    'illinois indiana iowa kansas kentucky louisiana maine maryland massachusetts michigan minnesota ' +
    'mississippi missouri montana nebraska nevada ohio oklahoma oregon pennsylvania tennessee texas utah ' +
    'vermont virginia washington wisconsin wyoming ' +
    'north|carolina north|dakota south|carolina south|dakota new|york new|jersey new|mexico ' +
    'new|hampshire west|virginia rhode|island district|of|columbia puerto|rico ' +
    'us usa canada uk india australia germany france ireland mexico netherlands spain poland brazil japan ' +
    'singapore philippines remote').split(' ').map((r) => r.replace(/\|/g, ' ')));

  const isRealRegion = (t) => REGIONS.has(String(t || '').toLowerCase().replace(/[^a-z ]/g, '').trim());

  // Every URL that identifies THIS posting, beyond the page we are standing on.
  //
  // This is the single highest-value thing the extension can report. Two
  // aggregators (LinkedIn and Indeed, say) assign one job two unrelated ids, so
  // nothing in their URLs can link them - but both usually link out to the SAME
  // employer requisition. Reporting that link lets TalentOS recognise them as one
  // posting with certainty, instead of inferring it from title/company text.
  function collectIdentityUrls() {
    const out = new Set();
    const here = location.hostname.replace(/^www\./, '');
    const add = (u) => {
      if (!u || typeof u !== 'string') return;
      try {
        const h = new URL(u, location.href);
        if (h.protocol.indexOf('http') === 0) out.add(h.href.split('#')[0]);
      } catch (e) { /* not a usable url */ }
    };

    for (const x of jobPostings()) {
      add(x.url); add(x.applyUrl);
      const target = x.potentialAction?.target;
      add(typeof target === 'string' ? target : target?.urlTemplate);
    }

    // Only accept an unambiguous external apply target; recommendations can
    // carry other jobs' apply links and must never become this job's identity.
    const applyTargets = new Set();
    for (const a of (document.querySelector('#job-details, #jobDescriptionText, [data-test="jobDetails"], main') || document).querySelectorAll('a[href]')) {
      const label = ((a.innerText || '') + ' ' + (a.getAttribute('aria-label') || '')).trim();
      let host = '';
      try { host = new URL(a.href, location.href).hostname.replace(/^www\./, ''); } catch (e) { continue; }
      if (!host || host === here) continue;
      if (/\bapply\b/i.test(label) && !/other|similar|more jobs/i.test(label) && !a.closest('[data-test="similarJobs"], [class*="recommend" i]')) applyTargets.add(a.href);
    }
    if (applyTargets.size === 1) add([...applyTargets][0]);
    return Array.from(out);
  }

  function htmlToText(h) {
    const d = document.createElement('div');
    d.innerHTML = String(h || '');
    d.querySelectorAll('script,style').forEach((x) => x.remove());
    return (d.innerText || d.textContent || '').replace(/\n{3,}/g, '\n\n').trim();
  }

  function report(status, percent, message, detail = '') {
    chrome.runtime.sendMessage({ action: 'captureProgress', status, percent, message, detail },
      () => void chrome.runtime.lastError);
  }

  // Async-render wait. NEVER busy-loop — it freezes the renderer (learned the hard way).
  async function waitFor(fn, { timeout = 10000, interval = 300 } = {}) {
    const end = Date.now() + timeout;
    while (Date.now() < end) {
      const v = fn();
      if (v) return v;
      await delay(interval);
    }
    return null;
  }

  // ───────── TIER 1: JSON-LD ─────────
  function fromJsonLd(scope = document) {
    for (const x of jobPostings(scope)) {
        const a = x.jobLocation?.address || x.jobLocation?.[0]?.address || {};
        const v = x.baseSalary?.value || {};
        return {
          method: 'jsonld',
          title: clean(x.title),
          company: employer(x.hiringOrganization?.name),
          location: clean([a.addressLocality, a.addressRegion, a.addressCountry].filter(Boolean).join(', ')),
          jdText: htmlToText(x.description),
          postedAt: x.datePosted || null,
          employmentType: Array.isArray(x.employmentType) ? x.employmentType[0] : x.employmentType || null,
          salary: (v.minValue || v.maxValue)
            ? `${v.minValue ?? ''}${v.maxValue ? '-' + v.maxValue : ''} ${x.baseSalary?.currency || ''} ${v.unitText || ''}`.trim()
            : null,
          isRemote: /telecommute|remote/i.test(String(x.jobLocationType || '')),
        };
    }
    return null;
  }

  // ───────── TIER 1b: microdata ─────────
  function fromMicrodata() {
    const md = document.querySelector('[itemtype*="schema.org/JobPosting" i]');
    if (!md) return null;
    const ip = (n) => clean(T(md.querySelector(`[itemprop="${n}"]`)));
    const jd = T(md.querySelector('[itemprop="description"]'));
    if (!ip('title') || jd.length < 150) return null;
    return { method: 'microdata', title: ip('title'), company: ip('hiringOrganization'),
      location: ip('jobLocation'), jdText: jd,
      postedAt: md.querySelector('[itemprop="datePosted"]')?.getAttribute('content') || null,
      employmentType: ip('employmentType') || null, salary: ip('baseSalary') || null, isRemote: false };
  }

  // ───────── TIER 2: site adapters ─────────
  async function expandLinkedIn() {
    const btns = [
      ...document.querySelectorAll('[data-testid="expandable-text-button"]'),
      ...document.querySelectorAll('button.jobs-description__footer-button, button[aria-label*="see more" i]'),
    ];
    let n = 0;
    for (const b of btns) { const t = (b.innerText || '').toLowerCase(); if (t.includes('more') || t.includes('…')) { b.click(); n++; } }
    if (n) await delay(500);
  }

  function jobDescription(scope = document) {
    for (const selector of ['#job-details', '.jobs-description__content', '.show-more-less-html__markup', '[data-sdui-component*="aboutTheJob"]', '#jobDescriptionText', '.simple-job-description-html', '.react-native-html-content', '[data-test="jobDescriptionContent"]']) {
      const text = T(scope.querySelector(selector));
      if (text.length >= 150) return text;
    }
    return [...scope.querySelectorAll('[data-testid="expandable-text-box"]')]
      .map(T).sort((a, b) => b.length - a.length)[0] || '';
  }

  function companyFromDescription(text) {
    const match = String(text || '').match(/(?:^|\n)\s*(?:company description|about (?:the )?company)\s*:?\s+([^\n.!?]{2,140}?)\s+(?:is|provides|specializes|offers|delivers|was founded)\b/i);
    return match && !/^(we|our company|the company|this company)$/i.test(match[1]) ? employer(match[1]) : '';
  }

  function linkedinInfo(scope = document, description = '') {
    const titleNode = scope.querySelector('.job-details-jobs-unified-top-card__job-title, [data-testid="job-title"], .top-card-layout__title, h1');
    const header = titleNode?.closest('.job-details-jobs-unified-top-card, .top-card-layout, [data-testid="job-details-top-card"]')
      || titleNode?.parentElement?.parentElement?.parentElement || scope;
    const rawTitles = [scope.title, meta('og:title', scope), meta('twitter:title', scope)].filter(Boolean).map(clean);
    const hiring = rawTitles.map(t => t.split('|')[0].match(/^(.+?)\s+hiring\s+(.+)$/i)).find(Boolean);
    const atTitle = rawTitles.map(t => t.split('|')[0].match(/^(.+?)\s+at\s+(.+?)(?:\s+in\s+[^|]+)?$/i)).find(Boolean);
    const metadataTitle = hiring ? hiring[2].replace(/\s+in\s+[^|]+$/i, '') : atTitle?.[1];
    let company = '';
    for (const selector of ['.job-details-jobs-unified-top-card__company-name a', '.job-details-jobs-unified-top-card__company-name', '.topcard__org-name-link', '[data-testid="company-name"]', '[data-testid="companyName"]', '[data-testid="company-name-link"]']) {
      company = employer(T(scope.querySelector(selector)));
      if (company) break;
    }
    // SDUI uses accessible company labels as well as ordinary company links.
    if (!company) {
      const aria = [...header.querySelectorAll('[aria-label]'), ...scope.querySelectorAll('[aria-label^="Company,"]')]
        .map(e => e.getAttribute('aria-label')).find(t => /^Company\s*[:,]/i.test(t || ''));
      company = employer((aria || '').replace(/^Company\s*[:,]\s*/i, '').replace(/\.$/, ''));
    }
    if (!company) {
      const names = [...header.querySelectorAll('a[href*="/company/"]')]
        .filter(a => !a.closest('aside, nav, [class*="recommend" i], [class*="similar-jobs" i]'))
        .map(a => employer(T(a))).filter(t => t && t.length <= 140 && !/^(follow|view|see who|show all)\b/i.test(t));
      const unique = [...new Set(names)];
      if (unique.length === 1) company = unique[0];
    }
    company = company || employer(hiring?.[1]) || employer(atTitle?.[2]);
    if (!company) {
      const logo = [...header.querySelectorAll('img[alt]')].map(e => e.alt.match(/^(.+?)\s+logo$/i)).find(Boolean);
      company = employer(logo?.[1]);
    }
    company = company || companyFromDescription(description);
    const primary = firstText(scope, ['.job-details-jobs-unified-top-card__primary-description-container', '.topcard__flavor--bullet', '[data-testid="job-location"]']);
    const lines = T(header).split('\n').map(clean);
    const locationLine = lines.find(t => t.includes(',') && !t.includes(company) && /·|remote|hybrid|on-site|, [A-Z][A-Za-z ]+$/.test(t)) || '';
    return { method: 'adapter:linkedin', title: clean(T(titleNode)) || metadataTitle || clean(rawTitles[0]?.split('|')[0]),
      company, location: clean((primary || locationLine).split('·')[0]), jdText: description,
      postedAt: header.querySelector('time[datetime]')?.getAttribute('datetime') || null,
      employmentType: /full[- ]time/i.test(T(header) + ' ' + description) ? 'FULL_TIME' : null,
      salary: null, isRemote: /\bremote\b/i.test(primary || locationLine) };
  }

  async function linkedin() {
    await waitFor(() => jobDescription() || document.querySelector('h1, .job-details-jobs-unified-top-card__job-title'), { timeout: 6000 });
    await expandLinkedIn();
    let result = linkedinInfo(document, jobDescription());
    if (!result.company) {
      await waitFor(() => {
        result = linkedinInfo(document, jobDescription());
        return result.company;
      }, { timeout: 2000, interval: 250 });
    }
    return result;
  }

  function mergeMissing(target, source) {
    if (!source) return target;
    if (!target) return source;
    for (const key of ['title', 'company', 'location', 'postedAt', 'employmentType', 'salary']) {
      if (!target[key] && source[key]) target[key] = source[key];
    }
    if ((target.jdText || '').trim().length < 150 && (source.jdText || '').length > (target.jdText || '').length) target.jdText = source.jdText;
    return target;
  }

  async function recoverMissingFields(result) {
    const incomplete = r => !r?.title || !r?.company || (r.jdText || '').trim().length < 150;
    if (!incomplete(result)) return result;
    const isLinkedIn = /(^|\.)linkedin\.com$/i.test(location.hostname);
    if (isLinkedIn) result = mergeMissing(result, linkedinInfo(document, jobDescription()));
    if (!incomplete(result)) return result;
    const id = new URL(postingUrl()).pathname.match(/\/jobs\/view\/(?:[^/]*-)?(\d+)/)?.[1];
    const urls = isLinkedIn && id ? [`${location.origin}/jobs-guest/jobs/api/jobPosting/${id}`, postingUrl()] : [postingUrl()];
    for (const url of urls) {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 5000);
      try {
        const response = await fetch(url, { credentials: url.includes('/jobs-guest/') ? 'omit' : 'same-origin', signal: controller.signal });
        if (!response.ok) continue;
        const html = await response.text();
        if (html.length > 4000000) continue;
        const doc = new DOMParser().parseFromString(html, 'text/html');
        if (/^(just a moment|access denied|verify.*human|security check|sign in|log in)/i.test(doc.title.trim())) continue;
        let recovered = fromJsonLd(doc);
        const jd = jobDescription(doc);
        if (isLinkedIn) recovered = mergeMissing(recovered, linkedinInfo(doc, jd));
        else if (/(^|\.)indeed\.[a-z.]+$/i.test(location.hostname)) recovered = mergeMissing(recovered, indeedInfo(doc));
        else if (/(^|\.)glassdoor\.[a-z.]+$/i.test(location.hostname)) recovered = mergeMissing(recovered, glassdoorInfo(doc));
        else recovered = mergeMissing(recovered, {
          method: 'static:posting', title: firstText(doc, ['[data-test="job-title"]', '[data-testid="jobsearch-JobInfoHeader-title"]', '.jobsearch-JobInfoHeader-title', 'h1']),
          company: employer(firstText(doc, ['[data-testid="inlineHeader-companyName"] a', '[data-testid="inlineHeader-companyName"]', '[data-testid="company-name"]', '[data-test="employerName"]', '[itemprop="hiringOrganization"] [itemprop="name"]'])) || companyFromDescription(jd),
          location: firstText(doc, ['[data-test="location"]', '[data-testid="job-location"]', '[data-testid="text-location"]']), jdText: jd,
        });
        result = mergeMissing(result, recovered);
        if (!incomplete(result)) break;
      } catch { /* Keep the visible-page result when public recovery is unavailable. */ }
      finally { clearTimeout(timeout); }
    }
    return result;
  }

  function indeedInfo(scope = document) {
    const title = scope.querySelector('[data-testid="vj-job-title"], [data-testid="jobsearch-JobInfoHeader-title"], .jobsearch-JobInfoHeader-title');
    const pane = title?.closest('[data-testid="viewjob-main-content"], .jobsearch-RightPane, #jobsearch-ViewjobPaneWrapper, .jobsearch-ViewJobLayout-jobDisplay') || scope;
    const header = title?.closest('[data-testid="desktop-job-header"], .jobsearch-JobInfoHeader') || pane;
    const metadata = header.querySelector('[data-testid="company-info-metadata"]');
    let company = '';
    // Current Indeed headers expose a company profile link, without the old
    // company-name test ID. Stay inside the selected job header, away from Home,
    // footer employer links, and companies on recommended job cards.
    for (const selector of ['[data-testid="company-info-metadata"] a[href*="/cmp/"]', '[data-testid="inlineHeader-companyName"] a', '[data-testid="inlineHeader-companyName"]', '[data-testid="company-name"]', '.jobsearch-InlineCompanyRating-companyHeader a', '.jobsearch-InlineCompanyRating-companyHeader']) {
      const link = header.querySelector(selector);
      const text = T(link) || link?.getAttribute('aria-label') || '';
      company = employer(text.replace(/\s*\(opens in a new tab\)\s*$/i, ''));
      if (company) break;
    }
    if (!company && header !== scope) {
      const candidates = [...header.querySelectorAll('a[href*="/cmp/"]')]
        .filter(a => !a.closest('nav, footer, aside, [class*="recommend" i]'))
        .map(a => employer(T(a))).filter(Boolean);
      const unique = [...new Set(candidates)];
      if (unique.length === 1) company = unique[0];
    }
    let locationText = firstText(header, ['[data-testid="job-location"]', '[data-testid="inlineHeader-companyLocation"]', '[data-testid="text-location"]', '#jobLocationText']);
    if (!locationText && metadata) {
      // Location is an unlabelled sibling of the company link in the new layout.
      // Accept a complete city/region value, never arbitrary description prose.
      const nodes = [...metadata.querySelectorAll('[dir="ltr"]')].filter(e => !e.closest('a') && !e.querySelector('a'));
      locationText = nodes.map(e => clean(T(e))).find(text => {
        const match = text.match(/^([\p{L}.' -]{2,80}),\s*([\p{L}. ]{2,60})$/u);
        return match && isRealRegion(match[2]);
      }) || '';
    }
    const details = T(pane.querySelector('[data-testid="jobDetailsSection"], #jobDetailsSection'));
    const pay = (T(header) + '\n' + details).match(/\$[\d,]+(?:\s*[-–]\s*\$[\d,]+)?\s*(?:an?|per)?\s*(?:year|hour|month)?/i);
    return { method: 'adapter:indeed', title: clean(T(title)), company,
      location: locationText, jdText: jobDescription(pane),
      externalId: new URL(postingUrl()).searchParams.get('jk') || null,
      postedAt: null, salary: pay ? clean(pay[0]) : null,
      employmentType: /full[- ]time/i.test(details) ? 'FULL_TIME' : null,
      isRemote: /\bremote\b/i.test(locationText) };
  }

  async function indeed() {
    await waitFor(() => document.querySelector('[data-testid="vj-job-title"], [data-testid="jobsearch-JobInfoHeader-title"], .jobsearch-JobInfoHeader-title'));
    let result = indeedInfo();
    if (!result.company || result.jdText.length < 150) {
      await waitFor(() => {
        result = indeedInfo();
        return result.company && result.jdText.length >= 150;
      }, { timeout: 2500, interval: 250 });
    }
    return result;
  }

  function glassdoorInfo(scope = document) {
    const description = scope.querySelector('[data-test="jobDescriptionContent"], [data-test="jobDescription"], [class*="JobDetails_jobDescription__"]');
    const selectedTitle = scope.querySelector('[id^="jd-job-title-"]');
    // A JobDetails_jobDetailsHeader is only a header, not the full job pane.
    // Use the smallest shared ancestor of the selected title and description.
    let pane = selectedTitle;
    while (pane && description && !pane.contains(description)) pane = pane.parentElement;
    if (!description || !pane) pane = scope.querySelector('[data-test="jobDetails"], [data-test="job-details"]') || scope;
    return { method: 'adapter:glassdoor',
      title: clean(T(selectedTitle)) || firstText(pane, ['[data-test="job-title"]', '[data-test="jobTitle"]', 'h1']),
      company: employer(firstText(pane, ['[class*="EmployerProfile_employerNameHeading"]', '[data-test="employerName"]', '[data-test="employer-name"]', '[class*="EmployerProfile_compactEmployerName"]'])),
      location: firstText(pane, ['[data-test="location"]', '[data-test="location-name"]', '[data-test="job-location"]', '[class*="JobDetails_location"]']),
      jdText: T(description),
      externalId: selectedTitle?.id.replace('jd-job-title-', '') || null,
      postedAt: null, salary: firstText(pane, ['[id^="jd-salary-"]', '[data-test="detailSalary"]', '[data-test="salary-estimate"]']) || null,
      employmentType: null, isRemote: false };
  }

  async function glassdoor() {
    await waitFor(() => document.querySelector('[data-test="jobDescriptionContent"], [data-test="jobDescription"], [class*="JobDetails_jobDescription__"]'), { timeout: 6000 });
    return glassdoorInfo();
  }

  const ADAPTERS = [
    { m: (u) => /linkedin\.com\/jobs\//.test(u), f: linkedin },
    { m: (u) => /indeed\.[a-z.]+\/(viewjob|jobs|job)/.test(u), f: indeed },
    { m: (u) => /glassdoor\.[a-z.]+\//.test(u), f: glassdoor },
  ];

  // ───────── TIER 3: generic brute force (LIVE-TESTED on Greenhouse + WWR) ─────────
  function generic() {
    const h1 = clean(T(document.querySelector('h1'))).split('\n')[0];
    const ogT = clean(meta('og:title'));
    const docParts = document.title.split(/\s*[|\-–—]\s*/).map(clean).filter(Boolean);
    const site = clean(meta('og:site_name'));
    const signals = [];
    const title = h1 || ogT || docParts[0] || '';
    if (h1) signals.push('h1'); else if (ogT) signals.push('og:title');

    // company: LD Organization → "…at Company" → og:site_name → last title part
    let company = '';
    for (const s of document.querySelectorAll('script[type="application/ld+json"]')) {
      let p; try { p = JSON.parse(s.textContent); } catch { continue; }
      const arr = Array.isArray(p) ? p : (Array.isArray(p['@graph']) ? p['@graph'] : [p]);
      // A JobPosting's hiringOrganization IS the employer by definition, so
      // prefer it over a standalone Organization node and over any page-level
      // fallback. Reaching og:site_name means we report the SITE as the
      // employer, which is how "Indeed.com" ended up stored as a company.
      const posting = arr.find((x) => x?.['@type'] === 'JobPosting' && x?.hiringOrganization?.name);
      if (posting) { company = clean(posting.hiringOrganization.name); signals.push('ld:hiringOrganization'); break; }
      const org = arr.find((x) => x?.['@type'] === 'Organization');
      if (!isJobBoard && org?.name) { company = clean(org.name); signals.push('ld:Organization'); break; }
    }
    if (!company) { const m = document.title.match(/\bat\s+([^|\-–—]{2,60})/i); if (m) { company = clean(m[1]); signals.push('title:at'); } }
    if (!company && site && !isJobBoard) { company = site; }
    if (!company && !isJobBoard && docParts.length >= 2) { company = docParts[docParts.length - 1]; }

    // JD block scoring
    const KW = /responsibilit|qualificat|requirement|experience|benefit|about the (job|role)|what you|we are looking|skills|salary|compensation|apply/i;
    let best = null, bestScore = 0;
    document.querySelectorAll('div,section,article,main,td').forEach((e) => {
      const t = T(e), len = t.length;
      if (len < 400 || len > 60000) return;
      const linkLen = [...e.querySelectorAll('a')].reduce((s, a) => s + T(a).length, 0);
      const linkRatio = linkLen / Math.max(1, len);
      if (linkRatio > 0.4) return;                       // nav/list, not prose
      const kw = (t.match(KW) || []).length;
      let sc = Math.log(len) * 10 + kw * 25 - e.querySelectorAll('div,section').length * 0.4 - linkRatio * 60;
      if (e.tagName === 'ARTICLE' || e.tagName === 'MAIN') sc += 15;
      if (/job|description|posting|content|detail/i.test(String(e.className) + e.id)) sc += 20;
      if (sc > bestScore) { bestScore = sc; best = e; }
    });
    const jdText = T(best);
    if (jdText) signals.push('heuristic:block');

    const scope = (jdText || document.body.innerText).slice(0, 4000);
    // Only accept "City, Region" when Region really names a region.
    let loc = null;
    const LOC_RE = /\b([A-Z][A-Za-z.'\-]+(?: [A-Z][A-Za-z.'\-]+){0,3}),\s*([A-Z]{2}\b|[A-Z][a-z]+(?: [A-Z][a-z]+)?)/g;
    for (const m of scope.matchAll(LOC_RE)) {
      if (isRealRegion(m[2])) { loc = m; break; }
    }
    const remote = /\bremote\b|\bwork from home\b|\btelecommute\b/i.test(scope);
    const sal = scope.match(/(?:\$|USD\s?)[\d,]+(?:\.\d+)?\s*(?:-|–|to)\s*(?:\$|USD\s?)?[\d,]+(?:\.\d+)?(?:\s*(?:per|a|\/)\s*(?:year|yr|hour|hr|month))?/i)
             || scope.match(/(?:\$|USD\s?)[\d,]{4,}(?:\s*(?:per|a|\/)\s*(?:year|yr|hour|hr))?/i);

    return { method: 'generic', title: clean(title), company: employer(company),
      location: loc ? clean(loc[1] + ', ' + loc[2]) : (remote ? 'Remote' : ''), jdText,
      postedAt: null, employmentType: /full[- ]time/i.test(scope) ? 'FULL_TIME' : null,
      salary: sal ? clean(sal[0]) : null, isRemote: remote, signals };
  }

  // ───────── confidence ─────────
  function score(r) {
    if (!r) return 0;
    let b = r.method === 'jsonld' ? 92 : r.method === 'microdata' ? 85 : r.method.startsWith('adapter') ? 72 : 34;
    if (!r.title) b -= 30;
    if (!r.company) b -= 15;
    if ((r.jdText || '').length < 200) b -= 35;
    if (!r.location) b -= 5;
    if ((r.jdText || '').length > 1500) b += 5;
    return Math.max(0, Math.min(100, b));
  }

  // ───────── MODE B: search-page cards ─────────
  // Outermost filtering is MANDATORY — without it Indeed matched 968 nested
  // elements and produced duplicate cards.
  function detectCards() {
    const SELS = ['[data-jk]', '[data-occludable-job-id]', '.job_seen_beacon', '.job-card-container',
      '[data-testid="job-card"]', 'tr.job-post', 'li.feature', '.posting', '[data-test="jobListing"]', '[data-test="job-card"]',
      '[class*="job_result" i]', '[class*="job-card" i]', '[class*="jobCard" i]', 'article'];
    const outermost = (els) => els.filter((e) => !els.some((o) => o !== e && o.contains(e)));
    for (const sel of SELS) {
      let els; try { els = [...document.querySelectorAll(sel)]; } catch { continue; }
      if (els.length < 3) continue;
      els = outermost(els).filter((e) => e.querySelector('a[href]') || e.matches('a[href]'));
      if (els.length < 3 || els.length > 200) continue;
      const lens = els.map((e) => T(e).length).filter((l) => l > 20);
      if (lens.length < 3) continue;
      if (lens.reduce((a, b) => a + b, 0) / lens.length < 40) continue;
      return { sel, els };
    }
    return null;
  }

  function extractCards() {
    const found = detectCards();
    if (!found) return [];
    const host = location.hostname;
    return found.els.map((el) => {
      const a = el.querySelector('a[href*="/jobs/view/"], a[href*="/viewjob"], a[href*="/job-listing/"], a[href]') || (el.matches('a[href]') ? el : null);
      const lines = [...new Set(T(el).split('\n').map((l) => l.trim()).filter(Boolean))];
      const id = el.getAttribute('data-jk') || el.getAttribute('data-occludable-job-id') || null;
      let url = a?.href || null;
      if (/linkedin\.com/.test(host) && id) url = `https://www.linkedin.com/jobs/view/${id}`;
      if (/indeed\.com/.test(host) && id) url = `https://${host}/viewjob?jk=${id}`;
      const company = employer(T(el.querySelector('[data-testid="company-name"],[data-testid="companyName"],[data-test="employerName"],.artdeco-entity-lockup__subtitle,[class*="companyName" i]')) || lines[1] || '');
      let loc = clean(T(el.querySelector('[data-testid="text-location"],.job-card-container__metadata-wrapper,[class*="location" i]')) || lines[2] || '');
      if (company && loc.startsWith(company)) loc = clean(loc.slice(company.length)); // strip company prefix
      return {
        title: clean(T(el.querySelector('.job-card-list__title--link,a.job-card-container__link,h2 a span[title],h2,h3,[class*="title" i]')).split('\n')[0] || lines[0]),
        company, location: loc, externalId: id, applyUrl: url,
        jdText: '', method: 'card', confidence: 35, needsRecovery: true,
        sourceSite: host.replace(/^www\./, ''),
      };
    }).filter((c) => c.title && c.applyUrl);
  }

  // ───────── orchestration ─────────
  async function captureOne() {
    report('running', 15, 'Reading page');
    if (/^(just a moment|access denied|verify (?:you are|you're) human|security check|sign in|sign up|log in|join linkedin)/i.test(document.title.trim()) || /\/(authwall|signin|login)(?:\/|$)/i.test(location.pathname)) {
      throw new Error('This site is showing a sign-in or verification page. Complete it in the open tab, then capture the fully loaded posting again.');
    }
    if (/sorry (?:this|the) job is no longer available|this job (?:has expired|is no longer available)|this position (?:has been filled|is no longer available)|no longer accepting applications/i.test(T(document.body).slice(0, 4000))) {
      throw new Error('The source page says this posting is no longer accepting applications. Open a current posting to capture it.');
    }
    let r = fromJsonLd() || fromMicrodata();
    if (r) r.company = employer(r.company);
    if (!r || !r.company || !r.title || (r.jdText || '').length < 200) {
      const a = ADAPTERS.find((x) => x.m(location.href));
      if (a) { report('running', 45, 'Running site adapter'); const r2 = await a.f(); if (r2) { r2.company = employer(r2.company); if (score(r2) > score(r)) r = r2; else if (r) { for (const key of ['title', 'company', 'location', 'jdText']) if (!r[key] && r2[key]) r[key] = r2[key]; } } }
    }
    if (!r || score(r) < 45) { report('running', 70, 'Generic extraction'); const r3 = generic(); if (score(r3) > score(r)) r = r3; }
    r = await recoverMissingFields(r);
    if (!r) throw new Error('Nothing extractable on this page.');
    r.company = employer(r.company);
    const confidence = score(r);
    return { ...r, confidence, captureMethod: r.method,
      needsRecovery: confidence < 60 || (r.jdText || '').length < 200,
      applyUrl: postingUrl(), sourceUrl: postingUrl(), sourceSite: location.hostname.replace(/^www\./, ''),
      identityUrls: collectIdentityUrls(),
      capturedAt: new Date().toISOString(), idempotencyKey: crypto.randomUUID() };
  }

  async function run(mode) {
    if (window.__tosCapRunning) return null;
    window.__tosCapRunning = true;
    try {
      if (mode === 'cards') {
        report('running', 30, 'Scanning search results');
        const cards = extractCards().map((c) => ({ ...c, capturedAt: new Date().toISOString(), idempotencyKey: crypto.randomUUID() }));
        report('complete', 100, `${cards.length} jobs found`, 'Full descriptions will be read from each posting in your browser.');
        return { mode: 'cards', cards };
      }
      const job = await captureOne();
      report('complete', 100, `Captured (${job.confidence}%)`,
        '');
      return { mode: 'single', job };
    } catch (e) {
      report('failed', 0, 'Capture failed', e.message);
      throw e;
    } finally { window.__tosCapRunning = false; }
  }

  function hasOpenJob() {
    if (document.querySelector('[id^="jd-job-title-"]') && document.querySelector('[class*="JobDetails_jobDescription__"], [data-test="jobDescriptionContent"]')) return true;
    if (document.querySelector('[data-testid="vj-job-title"], [data-testid="jobsearch-JobInfoHeader-title"], .job-details-jobs-unified-top-card__job-title') && jobDescription().length >= 150) return true;
    return false;
  }

  function pageKind() {
    const u = location.href;
    if (/[?&](?:vjk|currentJobId|jl)=/.test(u)) return 'single';
    if (/linkedin\.com\/jobs\/(search|collections)/.test(u)) return 'search';
    if (/indeed\.com\/jobs\?/.test(u)) return 'search';
    if (/(ziprecruiter|dice|simplyhired)\.com\/(jobs|jobs-search|search)/.test(u)) return 'search';
    if (detectCards() && !fromJsonLd()) return 'search';
    return 'single';
  }

  chrome.runtime.onMessage.addListener((msg, _s, sendResponse) => {
    if (msg.action === 'detectPage') { sendResponse({ ok: true, kind: pageKind(), hasOpenJob: hasOpenJob() }); return true; }
    if (msg.action !== 'captureNow') return false;
    run(msg.mode).then((d) => sendResponse({ ok: true, ...d }))
                 .catch((e) => sendResponse({ ok: false, error: e.message }));
    return true;
  });

  console.log('[TalentOS Job Capture] ready —', pageKind());
}
